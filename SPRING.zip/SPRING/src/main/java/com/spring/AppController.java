package com.spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;


@Controller
public class AppController {
	
	
	

	@Autowired
	private UserRepository repo;
	
	
	@GetMapping("")
	public String homePage() {
		return "index";
	}

	@GetMapping("/register")
	public String register(Model m) {
		m.addAttribute("user", new User());

		return "register";
	}

	@PostMapping("/process_register")
	public String afterRegister(User user) 
	{
		BCryptPasswordEncoder encode=new BCryptPasswordEncoder();
		String encodedPassword=encode.encode(user.getPassword());
		user.setPassword(encodedPassword);
        
		
		
		repo.save(user);
		return "register_done";
	}
	
	@GetMapping("/upload")
	public String upload() {
		

		return "upload";
	}
	
	

}
